-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2023 at 11:58 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scd_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `Activity` varchar(10) NOT NULL,
  `Obtained Marks` int(10) NOT NULL,
  `Total Marks` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`Activity`, `Obtained Marks`, `Total Marks`) VALUES
('A-1', 9, 10),
('A-2', 7, 10),
('A-3', 10, 10),
('A-4', 9, 10),
('A-5', 8, 10),
('A-6', 0, 10),
('A-7', 7, 10),
('A-8', 6, 10);

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `01-June-2023` varchar(10) NOT NULL,
  `02-June-2023` varchar(10) NOT NULL,
  `03-June-2023` varchar(10) NOT NULL,
  `04-June-2023` varchar(10) NOT NULL,
  `05-June-2023` varchar(10) NOT NULL,
  `06-June-2023` varchar(10) NOT NULL,
  `07-June-2023` varchar(10) NOT NULL,
  `08-June-2023` varchar(10) NOT NULL,
  `09-June-2023` varchar(10) NOT NULL,
  `10-June-2023` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`01-June-2023`, `02-June-2023`, `03-June-2023`, `04-June-2023`, `05-June-2023`, `06-June-2023`, `07-June-2023`, `08-June-2023`, `09-June-2023`, `10-June-2023`) VALUES
('P', 'P', 'P', 'L', 'P', 'P', 'L', 'L', 'L', 'P'),
('P', 'P', 'P', 'P', 'A', 'P', 'P', 'P', 'A', 'A'),
('P', 'P', 'P', 'A', 'P', 'P', 'L', 'P', 'P', 'P'),
('P', 'P', 'A', 'A', 'P', 'P', 'P', 'P', 'P', 'P'),
('P', 'L', 'L', 'L', 'A', 'A', 'P', 'P', 'P', 'P'),
('P', 'A', 'P', 'P', 'P', 'P', 'P', 'P', 'L', 'L'),
('P', 'P', 'P', 'P', 'A', 'A', 'A', 'L', 'P', 'P'),
('P', 'P', 'P', 'A', 'A', 'P', 'P', 'P', 'P', 'P'),
('L', 'L', 'P', 'P', 'P', 'P', 'L', 'L', 'P', 'P');

-- --------------------------------------------------------

--
-- Table structure for table `enroll_course`
--

CREATE TABLE `enroll_course` (
  `Course` varchar(20) NOT NULL,
  `Section` int(10) NOT NULL,
  `Credit Hours` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `foam_gpa`
--

CREATE TABLE `foam_gpa` (
  `Course Title` text NOT NULL,
  `Grade` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `foam_gpa`
--

INSERT INTO `foam_gpa` (`Course Title`, `Grade`) VALUES
('artificial intelligence', 'A'),
('Data Science', 'A'),
('Software Quality Engineer', 'A'),
('MathA', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `gpa`
--

CREATE TABLE `gpa` (
  `Course Title` int(50) NOT NULL,
  `Grade` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_record`
--

CREATE TABLE `student_record` (
  `Name` varchar(10) NOT NULL,
  `Roll No` int(10) NOT NULL,
  `GPA` int(10) NOT NULL,
  `Program` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_record`
--

INSERT INTO `student_record` (`Name`, `Roll No`, `GPA`, `Program`) VALUES
('Usman', 30, 4, 'SE');

-- --------------------------------------------------------

--
-- Table structure for table `student_record_gpa`
--

CREATE TABLE `student_record_gpa` (
  `Course Title` text NOT NULL,
  `Grade` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_record_gpa`
--

INSERT INTO `student_record_gpa` (`Course Title`, `Grade`) VALUES
('Artificial Intelligence', 'A'),
('Data Science', 'A'),
('Software Quality Engineer', 'A'),
('Software Const & Develop ', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_t1`
--

CREATE TABLE `teacher_t1` (
  `Degree` text NOT NULL,
  `Institution` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_t1`
--

INSERT INTO `teacher_t1` (`Degree`, `Institution`) VALUES
('MS', 'Cust'),
('BS (CS)', 'Cust');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_t2`
--

CREATE TABLE `teacher_t2` (
  `Degree` text NOT NULL,
  `Institution` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_t2`
--

INSERT INTO `teacher_t2` (`Degree`, `Institution`) VALUES
('MPhil (CS)', 'Quaid-I-Azam University'),
('BS (SE)', 'University Faisalabad');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_t3`
--

CREATE TABLE `teacher_t3` (
  `Degree` text NOT NULL,
  `Institution` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_t3`
--

INSERT INTO `teacher_t3` (`Degree`, `Institution`) VALUES
('PhD (SE)', 'MAJU'),
('MS (SE)', 'NUST'),
('MSc (CS)', 'QAU'),
('BSc (physics)', 'PU');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `Activity` varchar(10) NOT NULL,
  `Obtained Marks` int(10) NOT NULL,
  `Total Marks` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`Activity`, `Obtained Marks`, `Total Marks`) VALUES
('Test 1', 8, 10),
('Test 2', 9, 10),
('Test 3', 9, 10),
('Test 4', 5, 10),
('Test 5', 10, 10);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
